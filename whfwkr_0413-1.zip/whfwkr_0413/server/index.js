const ws = require('ws');
const server = new ws.Server({ port: 3000 });
const http = require('http');
console.log('http 모듈 로드됨');

const clients = new Map();

// 사용자 목록을 모든 클라이언트에게 전송하는 함수
function broadcastUserList() {
    const users = Array.from(clients.values());
    const payload = {
        type: 'user-list',
        users: users,
        count: users.length // 사용자 수 추가
    };
    const jsonPayload = JSON.stringify(payload);

    clients.forEach((_, client) => {
        if (client.readyState === ws.OPEN) {
            client.send(jsonPayload);
            console.log('서버 -> 모든 클라이언트 (user-list):', jsonPayload);
        }
    });
}

server.on('connection', socket => {
    console.log('클라이언트 연결됨');
    let username;

    socket.on('message', async firstMessage => {
        console.log('첫 번째 메시지 수신 (타입):', typeof firstMessage);
        console.log('첫 번째 메시지 수신 (내용):', firstMessage.toString());
        if (!username) {
            username = firstMessage.toString().trim();
            if (!username) {
                username = `익명_${Math.random().toString(36).substring(7)}`;
            }
            clients.set(socket, username);
            console.log(`사용자 "${username}" 님이 접속했습니다.`);

            // 새로운 사용자가 접속했으므로 사용자 목록 업데이트 및 전송
            broadcastUserList();

            clients.forEach((name, client) => {
                if (client !== socket && client.readyState === ws.OPEN) {
                    const payload = {
                        type: 'system',
                        message: `${username} 님이 들어왔습니다.`,
                    };
                    const jsonPayload = JSON.stringify(payload);
                    client.send(jsonPayload);
                    console.log(`서버 -> "${name}" (join):`, jsonPayload);
                }
            });

            socket.removeAllListeners('message');

            socket.on('message', async message => {
                const messageStr = message.toString();
                const receivedMessage = message.toString();
                console.log(`"${username}" 님의 메시지 수신 (타입):`, typeof message);
                console.log(`"${username}" 님의 메시지 수신 (내용):`, receivedMessage);

                let parsed;
                try {
                    parsed = JSON.parse(messageStr);
                } catch (e) {
                    parsed = null;
                }

                // 이미지 처리
                if (parsed && parsed.type === 'image') {
                    const jsonPayload = JSON.stringify({
                        type: 'image',
                        sender: clients.get(socket),
                        imageData: parsed.imageData
                    });
                    clients.forEach((_, client) => {
                        if (client.readyState === ws.OPEN) {
                            client.send(jsonPayload);
                        }
                    });
                    return;
                }

                if (parsed && parsed.type === 'file') {
                    const jsonPayload = JSON.stringify({
                        type: 'file',
                        sender: clients.get(socket),
                        fileName: parsed.fileName,
                        fileData: parsed.fileData
                    });
                    clients.forEach((_, client) => {
                        if (client.readyState === ws.OPEN) {
                            client.send(jsonPayload);
                        }
                    });
                    return;
                }

                const postData = JSON.stringify({ message: receivedMessage });

                const options = {
                    hostname: 'localhost',
                    port: 5000,
                    path: '/analyze_sentiment',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(postData),
                    },
                };

                const req = http.request(options, (res) => {
                    let data = '';
                    res.on('data', (chunk) => {
                        data += chunk;
                    });
                    res.on('end', () => {
                        try {
                            const responseData = JSON.parse(data);
                            console.log('Flask API 응답:', responseData);
                            const payloadWithSentiment = {
                                type: 'message',
                                sender: username,
                                content: receivedMessage,
                                emotion: responseData.sentiment,
                            };
                            const jsonPayloadWithSentiment = JSON.stringify(payloadWithSentiment);
                            clients.forEach((name, client) => {
                                if (client.readyState === ws.OPEN) {
                                    client.send(jsonPayloadWithSentiment);
                                    console.log(`서버 -> "${name}" (message with emotion):`, jsonPayloadWithSentiment);
                                }
                            });
                        } catch (error) {
                            console.error('Flask API 응답 처리 오류:', error);
                            const payloadWithError = {
                                type: 'message',
                                sender: username,
                                content: receivedMessage,
                                emotion: '중립'
                            };
                            const jsonPayloadWithError = JSON.stringify(payloadWithError);
                            clients.forEach((name, client) => {
                                if (client.readyState === ws.OPEN) {
                                    client.send(jsonPayloadWithError);
                                }
                            });
                        }
                    });
                });

                req.on('error', (error) => {
                    console.error('Flask API 요청 오류:', error);
                    const payloadWithError = {
                        type: 'message',
                        sender: username,
                        content: receivedMessage,
                        emotion: '중립'
                    };
                    const jsonPayloadWithError = JSON.stringify(payloadWithError);
                    clients.forEach((name, client) => {
                        if (client.readyState === ws.OPEN) {
                            client.send(jsonPayloadWithError);
                        }
                    });
                });

                req.write(postData);
                req.end();
            });
        }
    });

    socket.on('close', () => {
        console.log(`사용자 "${username}" 님이 접속을 종료했습니다.`);
        clients.delete(socket);
        // 사용자가 나갔으므로 사용자 목록 업데이트 및 전송
        broadcastUserList();
        clients.forEach((name, client) => {
            if (client !== socket && client.readyState === ws.OPEN) {
                const payload = {
                    type: 'system',
                    message: `${username} 님이 나갔습니다.`,
                };
                const jsonPayload = JSON.stringify(payload);
                client.send(jsonPayload);
                console.log(`서버 -> "${name}" (leave):`, jsonPayload);
            }
        });
    });

    socket.on('error', error => {
        console.error('소켓 오류:', error);
        clients.delete(socket);
        // 에러 발생 시에도 사용자 목록 업데이트 및 전송 (선택 사항)
        broadcastUserList();
    });
});