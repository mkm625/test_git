const socket = new WebSocket('ws://localhost:3000');
let username;
let hasUsernameSent = false;
let userListVisible = false;
let userList = []; // 사용자 목록을 저장할 배열
let latestUserListPayload = null; // 최신 사용자 목록 데이터 저장

// 감정 이모지 맵
const emotionEmojiMap = {
    공포: '😱',
    놀람: '😲',
    분노: '😡',
    슬픔: '😢',
    중립: '🙂',
    행복: '😊',
    혐오: '🤢',
};

// 감정 이모지 반환 함수
function getEmotionEmoji(emotion) {
    return emotionEmojiMap[emotion] || '🙂';
}

document.addEventListener('DOMContentLoaded', () => {
    username = prompt('사용할 이름을 입력하세요:') || `익명_${Math.random().toString(36).substring(7)}`;
    localStorage.setItem('username', username); // 사용자 이름 로컬 스토리지에 저장
    socket.onopen = () => {
        console.log('웹소켓 연결 성공');
        socket.send(username);
        hasUsernameSent = true;
        console.log('WebSocket binaryType:', socket.binaryType);
        try {
            socket.binaryType = 'arraybuffer';
            console.log('WebSocket binaryType 변경 후:', socket.binaryType);
        } catch (error) {
            console.error('binaryType 변경 오류:', error);
        }

        // 본인 접속 메시지 생성 및 화면에 추가
        const now = new Date();
        const options = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
        const formattedDate = ` (${new Intl.DateTimeFormat('ko-KR', options).format(now)})`;
        const message = `${username} 님이 들어왔습니다.${formattedDate}`;

        const li = document.createElement('li');
        li.classList.add('system');
        const messageContent = document.createElement('div');
        messageContent.classList.add('message-content');
        messageContent.textContent = message;
        li.appendChild(messageContent);

        document.querySelector('#messages').appendChild(li);
        const messages = document.querySelector('#messages');
        messages.scrollTop = messages.scrollHeight;
    };
});

window.addEventListener("beforeunload", function (event) {
    event.preventDefault();
    event.returnValue = "";
});

document.getElementById('user-list').addEventListener('click', () => {
    const userListContainer = document.getElementById('user-list-container');
    userListVisible = !userListVisible;

    if (userListVisible) {
        // 사용자 목록 표시
        userListContainer.style.display = 'block';
        if (latestUserListPayload) {
            updateUserList(latestUserListPayload); // 최신 payload 사용
        }
    } else {
        userListContainer.style.display = 'none';
    }
});

document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');

    // 버튼 텍스트 변경
    document.getElementById('theme-toggle').textContent = isDarkMode ? '🌞' : '🌙';
    document.getElementById('tooltip-theme').textContent = isDarkMode ? '🌞 테마 전환' : '🌙 테마 전환';

    // 로컬스토리지에 테마 저장
    localStorage.setItem('darkMode', isDarkMode);
});

document.addEventListener('DOMContentLoaded', function () {
    const helpBtn = document.getElementById('help-btn');
    const helpOverlay = document.getElementById('help-overlay');

    const userBtn = document.getElementById('user-list');
    const themeBtn = document.getElementById('theme-toggle');
    const searchBtn = document.getElementById('search-btn');
    const tooltipUser = document.getElementById('tooltip-user');
    const tooltipTheme = document.getElementById('tooltip-theme');
    const tooltipSerach = document.getElementById('tooltip-search');
    const tooltipHelp = document.getElementById('tooltip-help');
    const tooltipEmo = document.getElementById('tooltip-emo');

    // 툴팁 위치를 설정하는 함수
    function setTooltipPositions() {
        const userRect = userBtn.getBoundingClientRect();
        const themeRect = themeBtn.getBoundingClientRect();
        const searchRect = searchBtn.getBoundingClientRect();
        const helpRect = helpBtn.getBoundingClientRect();
        const emoRect = helpBtn.getBoundingClientRect();

        tooltipUser.style.top = `${userRect.bottom + 10}px`;
        tooltipUser.style.left = `${userRect.left - 55}px`;

        tooltipTheme.style.top = `${themeRect.bottom + 10}px`;
        tooltipTheme.style.left = `${themeRect.left}px`;

        tooltipSerach.style.top = `${searchRect.bottom + 10}px`;
        tooltipSerach.style.left = `${searchRect.left - 25}px`;

        tooltipHelp.style.top = `${helpRect.bottom + 10}px`;
        tooltipHelp.style.left = `${helpRect.left}px`;

        tooltipEmo.style.top = `${emoRect.bottom}px`;
        tooltipEmo.style.left = `${emoRect.left + 80}px`;
    }

    helpBtn.addEventListener('click', () => {
        const visible = helpOverlay.style.display === 'block';
        helpOverlay.style.display = visible ? 'none' : 'block';

        if (!visible) {
            setTooltipPositions();
        }
    });

    // 페이지 크기 변경 시 툴팁 위치 다시 설정
    window.addEventListener('resize', setTooltipPositions);

    // 페이지 로드 시 첫 번째 툴팁 위치 설정
    helpOverlay.style.display = 'block';
    setTooltipPositions();
});

document.getElementById('action-menu-btn').addEventListener('click', () => {
    const menu = document.getElementById('action-menu');
    menu.style.display = (menu.style.display === 'flex') ? 'none' : 'flex';
});

document.getElementById('close-action-menu').addEventListener('click', () => {
    document.getElementById('action-menu').style.display = 'none';
});

// 페이지 로드 시 저장된 테마 상태 적용
window.addEventListener('DOMContentLoaded', () => {
    const isDarkMode = JSON.parse(localStorage.getItem('darkMode'));
    const hideHelpUntil = localStorage.getItem('hideHelpUntil');
    const now = new Date();

    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        document.getElementById('theme-toggle').textContent = '🌞';
    }

    if (hideHelpUntil && new Date(hideHelpUntil) > now) {
        helpContainer.style.display = "none";
    }
});


socket.onclose = () => {
    console.log('웹소켓 연결 종료');
};

socket.onerror = (error) => {
    console.error('웹소켓 오류:', error);
};

function scrollToBottom() {
    const messageList = document.querySelector('#messages');
    if (messageList) {
        messageList.scrollTop = messageList.scrollHeight;
    }
}

// 파일 첨부 버튼 누르면 input 트리거
document.getElementById('attach-file-btn').addEventListener('click', () => {
    document.getElementById('file-input').click();
});

// 파일 선택 처리
document.getElementById('file-input').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (!file || socket.readyState !== WebSocket.OPEN) return;

    const reader = new FileReader();
    reader.onload = () => {
        const payload = {
            type: 'file',
            sender: username,
            fileName: file.name,
            fileData: reader.result
        };
        socket.send(JSON.stringify(payload));
        scrollToBottom();
        document.getElementById('action-menu').style.display = 'none';
    };
    reader.readAsDataURL(file); // base64 인코딩

    event.target.value = ''; // 파일 선택 초기화
});

document.getElementById('attach-image-btn').addEventListener('click', () => {
    document.getElementById('image-input').click();
});

document.getElementById('image-input').addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (!file || socket.readyState !== WebSocket.OPEN) return;

    const reader = new FileReader();
    reader.onload = () => {
        const payload = {
            type: 'image',
            sender: username,
            imageData: reader.result
        };
        socket.send(JSON.stringify(payload));
        scrollToBottom(); // 이미지 전송 후 스크롤
        document.getElementById('action-menu').style.display = 'none';
    };
    reader.readAsDataURL(file);
    
    // 선택된 파일 초기화
    event.target.value = '';
});

function sendMessage(e) {
    e.preventDefault();
    const input = document.getElementById('message-input');
    const message = input.value.trim();

    if (!hasUsernameSent) {
        alert('아직 사용자 이름을 보내지 못했습니다.');
        return;
    }

    if (socket.readyState !== WebSocket.OPEN) {
        alert('웹소켓 연결이 끊어졌습니다.');
        return;
    }

    if (!message) {
        alert('메시지를 입력해주세요.');
        return;
    }

    socket.send(message);
    input.value = '';
    input.focus();
}

// 채팅 영역 드래그 앤 드롭 처리
const dropZone = document.getElementById('chat-container');

dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('drag-over');
});

dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('drag-over');
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');

    const file = e.dataTransfer.files[0];
    if (!file || socket.readyState !== WebSocket.OPEN) return;

    const reader = new FileReader();
    reader.onload = () => {
        let payload;

        if (file.type.startsWith('image/')) {
            payload = {
                type: 'image',
                sender: username,
                imageData: reader.result
            };
        } else {
            payload = {
                type: 'file',
                sender: username,
                fileName: file.name,
                fileData: reader.result
            };
        }

        socket.send(JSON.stringify(payload));
        scrollToBottom();

        // 드래그 업로드 후 기능 메뉴 닫기
        document.getElementById('action-menu').style.display = 'none';
    };

    reader.readAsDataURL(file);
});



// 이미지 클릭 시 모달로 원본 보기
document.addEventListener('click', function (e) {
    if (e.target.matches('img.chat-image')) {
        const modal = document.getElementById('image-modal');
        const modalImg = document.getElementById('modal-img');
        modal.style.display = 'block';
        modalImg.src = e.target.src;
    }
});

// 닫기 버튼으로 모달 닫기
document.getElementById('close-image-modal').addEventListener('click', () => {
    document.getElementById('image-modal').style.display = 'none';
});

// 모달 바깥 클릭하면 닫힘
window.addEventListener('click', (e) => {
    const modal = document.getElementById('image-modal');
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});

// ESC 키로도 닫기
window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        document.getElementById('image-modal').style.display = 'none';
    }
});


// form 태그 이벤트 리스너 수정
document.getElementById('message-form').addEventListener('submit', sendMessage);

let currentMatchIndex = -1; // 현재 강조된 메시지의 인덱스
let highlightedMessages =[]; // 강조된 메시지들

function searchMessages() {
    const searchText = document.querySelector("#search-input").value.trim().toLowerCase();
    const messages = Array.from(document.querySelectorAll("#messages li")).reverse();

    highlightedMessages = [];
    currentMatchIndex = -1;

    messages.forEach((li) => {
        const msg = li.querySelector(".message-content");
        if (!msg) return;

        const isSystem = li.classList.contains("system");
        const originalText = msg.textContent;

        if (!searchText || isSystem) {
            msg.innerHTML = escapeHtml(originalText);
            return;
        }

        const lowerText = originalText.toLowerCase();
        if (lowerText.includes(searchText)) {
            const regex = new RegExp(`(${escapeRegExp(searchText)})`, 'gi');
            msg.innerHTML = escapeHtml(originalText).replace(regex, '<span class="highlight-word">$1</span>');
            highlightedMessages.push(msg);
        } else {
            msg.innerHTML = escapeHtml(originalText);
        }
    });

    if (highlightedMessages.length > 0) {
        currentMatchIndex = 0;
        highlightedMessages[0].scrollIntoView({ behavior: "smooth", block: "center" });
    }

    // 💡 항상 맨 아래로 내리기
    document.querySelector("#chat-container").scrollTop = document.querySelector("#chat-container").scrollHeight;
}

function escapeHtml(text) {
    return text.replace(/[&<>"']/g, function (m) {
        return ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        })[m];
    });
}

function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function navigateSearchResults(direction) {
    if (highlightedMessages.length === 0) return;

    // 모든 강조 단어를 흐리게 처리
    document.querySelectorAll(".highlight-word").forEach(el => {
        el.classList.add("dimmed");
    });

    currentMatchIndex += direction;

    if (currentMatchIndex >= highlightedMessages.length) {
        currentMatchIndex = 0;
    } else if (currentMatchIndex < 0) {
        currentMatchIndex = highlightedMessages.length - 1;
    }

    // 현재 항목의 강조 단어는 다시 또렷하게
    highlightedMessages[currentMatchIndex].querySelectorAll(".highlight-word").forEach(el => {
        el.classList.remove("dimmed");
    });

    highlightedMessages[currentMatchIndex].scrollIntoView({ behavior: "smooth", block: "center" });
}

document.querySelector("#search-btn").addEventListener("click", () => {
    const searchBox = document.querySelector("#search-box");
    const searchBtn = document.querySelector("#search-btn");

    if (searchBox.style.display === "none" || searchBox.style.display === "") {
        searchBox.style.display = "flex"; // 검색창 표시
        searchBtn.style.display = "none"; // 검색 아이콘 숨기기
        document.querySelector("#search-input").focus(); // 검색창이 나타날 때 자동 포커스
    } else {
        searchBox.style.display = "none"; // 검색창 숨기기
        searchBtn.style.display = "block"; // 검색 아이콘 다시 표시
        document.querySelector("#search-input").value = ""; // 검색어 초기화
        searchMessages(); // 검색 초기화
    }
});

// ❌ 버튼을 클릭하면 검색창 숨기기
document.querySelector("#close-search").addEventListener("click", () => {
    const searchBox = document.querySelector("#search-box");
    const searchBtn = document.querySelector("#search-btn");

    searchBox.style.display = "none"; // 검색창 숨기기
    searchBtn.style.display = "block"; // 검색 아이콘 다시 표시
    document.querySelector("#search-input").value = ""; // 검색어 초기화
    searchMessages(); // 검색 초기화
});

document.querySelector("#next-btn").addEventListener("click", () => {
    navigateSearchResults(-1); // 다음 검색 결과로 이동
});

document.querySelector("#prev-btn").addEventListener("click", () => {
    navigateSearchResults(1); // 이전 검색 결과로 이동
});

socket.onmessage = (event) => {
    console.log('서버로부터 메시지 수신 (raw):', event.data);

    if (typeof event.data === 'string') {
        if (event.data.startsWith('{') && event.data.endsWith('}')) {
            try {
                const data = JSON.parse(event.data);
                console.log("수신된 데이터:", data);

                if (data.type === 'file') {
                    const li = document.createElement('li');
                    li.classList.add(data.sender === localStorage.getItem('username') ? 'me' : 'other');
                
                    const usernameDisplay = document.createElement('div');
                    usernameDisplay.classList.add('username');
                    usernameDisplay.textContent = data.sender;
                
                    const timeDisplay = document.createElement('div');
                    timeDisplay.classList.add('time');
                    const now = new Date();
                    const formattedDate = new Intl.DateTimeFormat('ko-KR', {
                        year: 'numeric', month: 'numeric', day: 'numeric',
                        hour: 'numeric', minute: 'numeric', second: 'numeric'
                    }).format(now);
                    timeDisplay.textContent = `📎 파일 | ${formattedDate}`;
                
                    const fileBox = document.createElement('div');
                    fileBox.classList.add('message-content'); // ✔️ 일반 메시지 스타일 재사용
                    const fileLink = document.createElement('a');
                    fileLink.href = data.fileData || '#';
                    fileLink.download = data.fileName || '파일';
                    fileLink.textContent = `${data.fileName || '파일'}`;
                    fileLink.style.wordBreak = 'break-word';
                    fileBox.appendChild(fileLink);
                
                    li.appendChild(usernameDisplay);
                    li.appendChild(timeDisplay);
                    li.appendChild(fileBox);
                
                    document.querySelector('#messages').appendChild(li);
                    scrollToBottom();
                    return;
                }


                if (data.type === 'user-list') {
                    console.log('수신된 사용자 목록 데이터:', data.users); // 이 부분을 추가
                    userList = data.users;
                    latestUserListPayload = data;
                    if (userListVisible) {
                        updateUserList(data);
                    }
                }
                console.log('서버로부터 메시지 수신 (parsed):', data);

                const now = new Date();
                const options = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
                const formattedDate = ` (${new Intl.DateTimeFormat('ko-KR', options).format(now)})`;

                let messageToDisplay;
                let messageClass;
                let senderName;
                let emotion = '중립';

                

                if (data.type === 'image' && data.imageData) {
                    const li = document.createElement('li');
                    li.classList.add(data.sender === localStorage.getItem('username') ? 'me' : 'other');
                
                    const img = document.createElement('img');
                    img.src = data.imageData;
                    img.classList.add('chat-image');
                    img.style.maxWidth = '200px';
                    img.style.borderRadius = '10px';
                    img.style.marginTop = '5px';
                
                    const usernameDisplay = document.createElement('div');
                    usernameDisplay.classList.add('username');
                    usernameDisplay.textContent = data.sender;
                
                    li.appendChild(usernameDisplay);
                    li.appendChild(img);
                
                    document.querySelector('#messages').appendChild(li);
                }

                if (data.type === 'message' && data.sender && data.content) {
                    senderName = data.sender;
                    messageToDisplay = data.content;
                    messageClass = (data.sender === localStorage.getItem('username')) ? 'me' : 'other';
                    if (data.emotion) {
                        emotion = data.emotion;
                    }
                    const emotionEmoji = getEmotionEmoji(emotion);
                    const timeWithEmotion = `${emotionEmoji} ${emotion} | ${formattedDate.replace(/[()]/g, '')}`;

                    const li = document.createElement('li');
                    li.classList.add(messageClass);

                    const profileIcon = document.createElement('div');
                    profileIcon.classList.add('profile-icon');
                    li.appendChild(profileIcon);

                    const usernameDisplay = document.createElement('div');
                    usernameDisplay.classList.add('username');
                    usernameDisplay.textContent = senderName;
                    li.appendChild(usernameDisplay);

                    const timeDisplay = document.createElement('div');
                    timeDisplay.classList.add('time');
                    timeDisplay.textContent = timeWithEmotion;
                    li.appendChild(timeDisplay);

                    const messageContent = document.createElement('div');
                    messageContent.classList.add('message-content');
                    messageContent.innerHTML = messageToDisplay;
                    li.appendChild(messageContent);

                    document.querySelector('#messages').appendChild(li);
                    const chatContainer = document.querySelector('#chat-container');
                    scrollToBottom();
                    console.log('메시지 표시됨:', { senderName, messageToDisplay, emotion });

                } else if (data.type === 'system' && data.message) {
                    messageToDisplay = `${data.message}${formattedDate}`;
                    messageClass = 'system';

                    const li = document.createElement('li');
                    li.classList.add(messageClass);
                    const messageContent = document.createElement('div');
                    messageContent.classList.add('message-content');
                    messageContent.textContent = messageToDisplay;
                    li.appendChild(messageContent);

                    document.querySelector('#messages').appendChild(li);
                    const chatContainer = document.querySelector('#chat-container');
                    scrollToBottom();
                    console.log('시스템 메시지 표시됨:', messageToDisplay);
                }

            } catch (error) {
                console.error("JSON 파싱 오류:", error, event.data);
            }
        } else {
            console.log('수신된 데이터 (비 JSON):', event.data);
        }
    }
}

function updateUserList({ users, count }) {
    const userListContainer = document.getElementById('user-list-container');
    userListContainer.innerHTML = '';

    const header = document.createElement('div');
    header.classList.add('user-list-header');
    header.textContent = `대화상대 (${count}명):`;  // 사용자 수 추가
    userListContainer.appendChild(header);

    const lineBreak = document.createElement('br');
    userListContainer.appendChild(lineBreak);

    // 참여자 목록 추가
    users.forEach(user => {
        const userItem = document.createElement('div');
        userItem.classList.add('user-item');
        userItem.textContent = user;
        userListContainer.appendChild(userItem);
    });
}

const helpBtn = document.querySelector("#help-btn");
const helpContainer = document.querySelector("#help-container");

// ❌ 버튼을 클릭하면 도움말 숨기기
document.querySelector("#close-help").addEventListener("click", () => {
    helpContainer.style.display = "none";
});

// ❌ 버튼을 클릭하면 도움말 숨기기
document.querySelector("#close-help-day").addEventListener("click", () => {
    helpContainer.style.display = "none";
    // 하루 뒤 시간 계산
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    localStorage.setItem('hideHelpUntil', tomorrow.toISOString());
});