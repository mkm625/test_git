const ws = require('ws');
const server = new ws.Server({ port: 3000 });
const http = require('http'); // http 모듈로 변경
console.log('http 모듈 로드됨');

const clients = new Map();

server.on('connection', socket => {
    console.log('클라이언트 연결됨');
    let username;

    socket.on('message', async firstMessage => { // message 핸들러를 async 함수로 변경
        console.log('첫 번째 메시지 수신 (타입):', typeof firstMessage);
        console.log('첫 번째 메시지 수신 (내용):', firstMessage.toString());
        if (!username) {
            username = firstMessage.toString().trim();
            if (!username) {
                username = `익명_${Math.random().toString(36).substring(7)}`;
            }
            clients.set(socket, username);
            console.log(`사용자 "${username}" 님이 접속했습니다.`);

            clients.forEach((name, client) => {
                if (client !== socket && client.readyState === ws.OPEN) {
                    const payload = {
                        type: 'system',
                        message: `${username} 님이 접속했습니다.`,
                    };
                    const jsonPayload = JSON.stringify(payload);
                    client.send(jsonPayload);
                    console.log(`서버 -> "${name}" (join):`, jsonPayload);
                }
            });

            socket.removeAllListeners('message');

            socket.on('message', async message => { // message 핸들러를 async 함수로 변경
                const receivedMessage = message.toString();
                console.log(`"${username}" 님의 메시지 수신 (타입):`, typeof message);
                console.log(`"${username}" 님의 메시지 수신 (내용):`, receivedMessage);

                const postData = JSON.stringify({ message: receivedMessage });

                const options = {
                    hostname: 'localhost',
                    port: 5000,
                    path: '/analyze_sentiment',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Content-Length': Buffer.byteLength(postData),
                    },
                };

                const req = http.request(options, (res) => { // http.request로 변경
                    let data = '';
                    res.on('data', (chunk) => {
                        data += chunk;
                    });
                    res.on('end', () => {
                        try {
                            const responseData = JSON.parse(data);
                            console.log('Flask API 응답:', responseData);
                            const payloadWithSentiment = {
                                type: 'message',
                                sender: username,
                                content: receivedMessage,
                                emotion: responseData.sentiment,
                            };
                            const jsonPayloadWithSentiment = JSON.stringify(payloadWithSentiment);
                            clients.forEach((name, client) => {
                                // 변경된 부분: client !== socket 조건 제거
                                if (client.readyState === ws.OPEN) {
                                    client.send(jsonPayloadWithSentiment);
                                    console.log(`서버 -> "${name}" (message with emotion):`, jsonPayloadWithSentiment);
                                }
                            });
                        } catch (error) {
                            console.error('Flask API 응답 처리 오류:', error);
                            const payloadWithError = {
                                type: 'message',
                                sender: username,
                                content: receivedMessage,
                                emotion: '중립'
                            };
                            const jsonPayloadWithError = JSON.stringify(payloadWithError);
                            clients.forEach((name, client) => {
                                if (client.readyState === ws.OPEN) {
                                    client.send(jsonPayloadWithError);
                                }
                            });
                        }
                    });
                });

                req.on('error', (error) => {
                    console.error('Flask API 요청 오류:', error);
                    const payloadWithError = {
                        type: 'message',
                        sender: username,
                        content: receivedMessage,
                        emotion: '중립'
                    };
                    const jsonPayloadWithError = JSON.stringify(payloadWithError);
                    clients.forEach((name, client) => {
                        if (client.readyState === ws.OPEN) {
                            client.send(jsonPayloadWithError);
                        }
                    });
                });

                req.write(postData);
                req.end();
            });
        }
    });

    socket.on('close', () => {
        console.log(`사용자 "${username}" 님이 접속을 종료했습니다.`);
        clients.delete(socket);
        clients.forEach((name, client) => {
            if (client !== socket && client.readyState === ws.OPEN) {
                const payload = {
                    type: 'system',
                    message: `${username} 님이 접속을 종료했습니다.`,
                };
                const jsonPayload = JSON.stringify(payload);
                client.send(jsonPayload);
                console.log(`서버 -> "${name}" (leave):`, jsonPayload);
            }
        });
    });

    socket.on('error', error => {
        console.error('소켓 오류:', error);
        clients.delete(socket);
    });
});