const socket = new WebSocket('ws://localhost:3000');
let username;
let hasUsernameSent = false;

// 감정 이모지 맵
const emotionEmojiMap = {
    공포: '😱',
    놀람: '😲',
    분노: '😡',
    슬픔: '😢',
    중립: '🙂',
    행복: '😊',
    혐오: '🤢',
};

// 감정 이모지 반환 함수
function getEmotionEmoji(emotion) {
    return emotionEmojiMap[emotion] || '🙂';
}

document.addEventListener('DOMContentLoaded', () => {
    username = prompt('사용할 이름을 입력하세요:') || `익명_${Math.random().toString(36).substring(7)}`;
    localStorage.setItem('username', username); // 사용자 이름 로컬 스토리지에 저장
    socket.onopen = () => {
        console.log('웹소켓 연결 성공');
        socket.send(username);
        hasUsernameSent = true;
        console.log('WebSocket binaryType:', socket.binaryType);
        try {
            socket.binaryType = 'arraybuffer';
            console.log('WebSocket binaryType 변경 후:', socket.binaryType);
        } catch (error) {
            console.error('binaryType 변경 오류:', error);
        }

        // 본인 접속 메시지 생성 및 화면에 추가
        const now = new Date();
        const options = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
        const formattedDate = ` (${new Intl.DateTimeFormat('ko-KR', options).format(now)})`;
        const message = `${username} 님이 접속 했습니다 .${formattedDate}`;

        const li = document.createElement('li');
        li.classList.add('system');
        const messageContent = document.createElement('div');
        messageContent.classList.add('message-content');
        messageContent.textContent = message;
        li.appendChild(messageContent);

        document.querySelector('#messages').appendChild(li);
        const chatContainer = document.querySelector('#chat-container');
        chatContainer.scrollTop = chatContainer.scrollHeight;
    };
});

document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const isDarkMode = document.body.classList.contains('dark-mode');

    // 버튼 텍스트 변경
    document.getElementById('theme-toggle').textContent = isDarkMode ? '라이트 모드' : '다크 모드';

    // 로컬스토리지에 테마 저장
    localStorage.setItem('darkMode', isDarkMode);
});

// 페이지 로드 시 저장된 테마 상태 적용
window.addEventListener('DOMContentLoaded', () => {
    const isDarkMode = JSON.parse(localStorage.getItem('darkMode'));
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        document.getElementById('theme-toggle').textContent = '라이트 모드';
    }
});

socket.onclose = () => {
    console.log('웹소켓 연결 종료');
};

socket.onerror = (error) => {
    console.error('웹소켓 오류:', error);
};

function sendMessage(e) {
    e.preventDefault();
    const input = document.getElementById('message-input');
    console.log('input.value:', input.value);
    console.log('hasUsernameSent:', hasUsernameSent);
    console.log('socket.readyState:', socket.readyState);
    if (input.value && hasUsernameSent && socket.readyState === WebSocket.OPEN) {
        const message = input.value;
        socket.send(message); // 서버로 메시지 전송
        input.value = "";
    } else {
        if (!hasUsernameSent) {
            alert('아직 사용자 이름을 보내지 못했습니다.');
        } else if (socket.readyState !== WebSocket.OPEN) {
            alert('웹소켓 연결이 끊어졌습니다.');
        } else if (!input.value) {
            alert('메시지를 입력해주세요.');
        }
    }
    input.focus();
}

// form 태그 이벤트 리스너 수정
document.getElementById('message-form').addEventListener('submit', sendMessage);

let currentMatchIndex = -1; // 현재 강조된 메시지의 인덱스
let highlightedMessages =[]; // 강조된 메시지들

function searchMessages() {
    const searchText = document.querySelector("#search-input").value.toLowerCase();
    const messages = document.querySelectorAll("#messages li .message-content");

    // 검색 결과 초기화
    highlightedMessages =[];

    messages.forEach((msg, index) => {
        const text = msg.textContent.toLowerCase();
        if (text.includes(searchText)) {
            msg.classList.add('highlighted');
            highlightedMessages.push(msg);
        } else {
            msg.classList.remove('highlighted');
        }
    });

    if (highlightedMessages.length > 0) {
        // 첫 번째 검색 결과로 스크롤
        highlightedMessages[0].scrollIntoView({ behavior: "smooth", block: "center" });
    }
}

function navigateSearchResults(direction) {
    if (highlightedMessages.length === 0) return;

    currentMatchIndex += direction;

    if (currentMatchIndex >= highlightedMessages.length) {
        currentMatchIndex = 0; // 마지막을 넘기면 처음으로 돌아감
    } else if (currentMatchIndex < 0) {
        currentMatchIndex = highlightedMessages.length - 1; // 첫 번째를 넘기면 마지막으로 돌아감
    }

    // 선택된 메시지로 스크롤
    highlightedMessages[currentMatchIndex].scrollIntoView({ behavior: "smooth", block: "center" });
}

document.querySelector("#search-btn").addEventListener("click", () => {
    const searchBox = document.querySelector("#search-box");
    const searchBtn = document.querySelector("#search-btn");

    if (searchBox.style.display === "none" || searchBox.style.display === "") {
        searchBox.style.display = "flex"; // 검색창 표시
        searchBtn.style.display = "none"; // 검색 아이콘 숨기기
        document.querySelector("#search-input").focus(); // 검색창이 나타날 때 자동 포커스
    } else {
        searchBox.style.display = "none"; // 검색창 숨기기
        searchBtn.style.display = "block"; // 검색 아이콘 다시 표시
        document.querySelector("#search-input").value = ""; // 검색어 초기화
        searchMessages(); // 검색 초기화
    }
});

// ❌ 버튼을 클릭하면 검색창 숨기기
document.querySelector("#close-search").addEventListener("click", () => {
    const searchBox = document.querySelector("#search-box");
    const searchBtn = document.querySelector("#search-btn");

    searchBox.style.display = "none"; // 검색창 숨기기
    searchBtn.style.display = "block"; // 검색 아이콘 다시 표시
    document.querySelector("#search-input").value = ""; // 검색어 초기화
    searchMessages(); // 검색 초기화
});

document.querySelector("#next-btn").addEventListener("click", () => {
    navigateSearchResults(1); // 다음 검색 결과로 이동
});

document.querySelector("#prev-btn").addEventListener("click", () => {
    navigateSearchResults(-1); // 이전 검색 결과로 이동
});

socket.onmessage = (event) => {
    console.log('서버로부터 메시지 수신 (raw):', event.data);

    if (typeof event.data === 'string') {
        if (event.data.startsWith('{') && event.data.endsWith('}')) {
            try {
                const data = JSON.parse(event.data);
                console.log('서버로부터 메시지 수신 (parsed):', data);

                const now = new Date();
                const options = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
                const formattedDate = ` (${new Intl.DateTimeFormat('ko-KR', options).format(now)})`;

                let messageToDisplay;
                let messageClass;
                let senderName;
                let emotion = '중립';

                if (data.type === 'message' && data.sender && data.content) {
                    senderName = data.sender;
                    messageToDisplay = data.content;
                    messageClass = (data.sender === localStorage.getItem('username')) ? 'me' : 'other';
                    if (data.emotion) {
                        emotion = data.emotion;
                    }
                    const emotionEmoji = getEmotionEmoji(emotion);
                    const timeWithEmotion = `${emotionEmoji} ${emotion} | ${formattedDate.replace(/[()]/g, '')}`;

                    const li = document.createElement('li');
                    li.classList.add(messageClass);

                    const profileIcon = document.createElement('div');
                    profileIcon.classList.add('profile-icon');
                    li.appendChild(profileIcon);

                    const usernameDisplay = document.createElement('div');
                    usernameDisplay.classList.add('username');
                    usernameDisplay.textContent = senderName;
                    li.appendChild(usernameDisplay);

                    const timeDisplay = document.createElement('div');
                    timeDisplay.classList.add('time');
                    timeDisplay.textContent = timeWithEmotion;
                    li.appendChild(timeDisplay);

                    const messageContent = document.createElement('div');
                    messageContent.classList.add('message-content');
                    messageContent.innerHTML = messageToDisplay;
                    li.appendChild(messageContent);

                    document.querySelector('#messages').appendChild(li);
                    const chatContainer = document.querySelector('#chat-container');
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                    console.log('메시지 표시됨:', { senderName, messageToDisplay, emotion });

                } else if (data.type === 'system' && data.message) {
                    messageToDisplay = `${data.message}${formattedDate}`;
                    messageClass = 'system';

                    const li = document.createElement('li');
                    li.classList.add(messageClass);
                    const messageContent = document.createElement('div');
                    messageContent.classList.add('message-content');
                    messageContent.textContent = messageToDisplay;
                    li.appendChild(messageContent);

                    document.querySelector('#messages').appendChild(li);
                    const chatContainer = document.querySelector('#chat-container');
                    chatContainer.scrollTop = chatContainer.scrollHeight;
                    console.log('시스템 메시지 표시됨:', messageToDisplay);
                }

            } catch (error) {
                console.error("JSON 파싱 오류:", error, event.data);
            }
        } else {
            console.log('수신된 데이터 (비 JSON):', event.data);
        }
    }


    const emotionEmoji = getEmotionEmoji(emotion);
    console.log('감정:', emotion, '이모지:', emotionEmoji);
    const timeWithEmotion = `${emotionEmoji} ${emotion} | ${formattedDate.replace(/[()]/g, '')}`;

    const li = document.createElement('li');
    li.classList.add(messageClass);

    if (messageClass !== 'system') {
        const profileIcon = document.createElement('div');
        profileIcon.classList.add('profile-icon');
        li.appendChild(profileIcon);

        const usernameDisplay = document.createElement('div');
        usernameDisplay.classList.add('username');
        usernameDisplay.textContent = senderName;
        li.appendChild(usernameDisplay);

        const timeDisplay = document.createElement('div');
        timeDisplay.classList.add('time');
        timeDisplay.textContent = timeWithEmotion;
        li.appendChild(timeDisplay);
    }

    const messageContent = document.createElement('div');
    messageContent.classList.add('message-content');
    messageContent.innerHTML = messageToDisplay;

    li.appendChild(messageContent);

    document.querySelector('#messages').appendChild(li);
    const chatContainer = document.querySelector('#chat-container');
    chatContainer.scrollTop = chatContainer.scrollHeight;
};