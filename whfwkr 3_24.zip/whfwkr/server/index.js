const ws = require('ws');
const server = new ws.Server({ port: 3000 });

const clients = new Map();

server.on('connection', socket => {
    console.log('클라이언트 연결됨');
    let username;

    socket.on('message', firstMessage => {
        console.log('첫 번째 메시지 수신 (타입):', typeof firstMessage);
        console.log('첫 번째 메시지 수신 (내용):', firstMessage.toString());
        if (!username) {
            username = firstMessage.toString().trim();
            if (!username) {
                username = `익명_${Math.random().toString(36).substring(7)}`;
            }
            clients.set(socket, username);
            console.log(`사용자 "${username}" 님이 접속했습니다.`);

            clients.forEach((name, client) => {
                if (client !== socket && client.readyState === ws.OPEN) {
                    const payload = {
                        type: 'system',
                        message: `${username} 님이 접속했습니다.`,
                    };
                    const jsonPayload = JSON.stringify(payload);
                    client.send(jsonPayload);
                    console.log(`서버 -> "${name}" (join):`, jsonPayload);
                }
            });

            socket.removeAllListeners('message');

            socket.on('message', message => {
                const receivedMessage = message.toString();
                console.log(`"${username}" 님의 메시지 수신 (타입):`, typeof message);
                console.log(`"${username}" 님의 메시지 수신 (내용):`, receivedMessage);
                const payload = {
                    type: 'message',
                    sender: username,
                    content: receivedMessage,
                };
                const jsonPayload = JSON.stringify(payload);
                console.log('서버에서 보내는 데이터:', jsonPayload);
                clients.forEach((name, client) => {
                    if (client !== socket && client.readyState === ws.OPEN) {
                        client.send(jsonPayload);
                        console.log(`서버 -> "${name}" (message):`, jsonPayload);
                    }
                });
            });
        }
    });

    socket.on('close', () => {
        console.log(`사용자 "${username}" 님이 접속을 종료했습니다.`);
        clients.delete(socket);
        clients.forEach((name, client) => {
            if (client !== socket && client.readyState === ws.OPEN) {
                const payload = {
                    type: 'system',
                    message: `${username} 님이 접속을 종료했습니다.`,
                };
                const jsonPayload = JSON.stringify(payload);
                client.send(jsonPayload);
                console.log(`서버 -> "${name}" (leave):`, jsonPayload);
            }
        });
    });

    socket.on('error', error => {
        console.error('소켓 오류:', error);
        clients.delete(socket);
    });
});